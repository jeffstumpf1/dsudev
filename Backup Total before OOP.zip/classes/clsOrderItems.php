<?php
/*
 Order Line Items
 clsOrderItems.php
*/
class OrderItems {

	var $part_number='';
	var $part_application='';
	var $part_pitch='';
	var $msrp=0;
	var $net_price=0;
	var $discount_percent=0;
	var $line_amount=0;

}
?>