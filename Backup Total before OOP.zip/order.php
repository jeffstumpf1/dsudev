<?php 
	header('Content-type: text/html; charset=utf-8');
	
	$debug = 'Off';
	require_once 'db/global.inc.php';
	
	function __autoload($class) {
		include 'classes/' . $class . '.class.php';
	}
   
   	// Create Object Customer and Request
	$constants = new Constants;
	$order = new Order($debug, $db);
	$request  = new Request;
	$utility  = new Utility($debug);
	
	// Setup the case
	switch ( strtolower($recMode ) ) {
	    case "a":
	        $recStatusDesc = "Adding new Order";
	        break; 
		case "d":	
			$recStatusDesc = "Making Order Inactive";
			break;
		case "e":
			$recStatusDesc = "Updating Order information";
			break;
		}
?>	

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.1//EN" "http://www.w3.org/TR/xhtml11/DTD/xhtml11.dtd"> 
<html lang='en' xml:lang='en' xmlns='http://www.w3.org/1999/xhtml'>

<head>
	<title>Order Entry</title>
	<link href="css/layout.css" media="screen, projection" rel="stylesheet" type="text/css" />
	<link href="css/style.css" media="screen, projection" rel="stylesheet" type="text/css" />
	<link rel="stylesheet" href="http://code.jquery.com/ui/1.10.3/themes/smoothness/jquery-ui.css" />
  	<script type="text/javascript" src="//ajax.googleapis.com/ajax/libs/jquery/1.8.1/jquery.min.js"></script>	
  	<script type="text/javascript" src="http://code.jquery.com/jquery-1.9.1.js"></script>
	<script type="text/javascript" src="http://code.jquery.com/ui/1.10.3/jquery-ui.js"></script>
	<link href="css/square/square.css" rel="stylesheet">
	<script type="text/javascript" src="js/jquery.icheck.js"></script>
	<script type="text/javascript" src="js/jquery.blockUI.js"></script>
	<script type="text/javascript" src="js/kit.js"></script>
	<script type="text/javascript" src="js/customer.js"></script>
	<script type="text/javascript" src="js/order.js"></script>
	
</head>
<body>


<div id="header">
	<h1>
		Drive Systems
	</h1>
</div>
<div id="wrapper">

<div id="navigation">
		<?php
		require "inc/nav.inc.php";
		?>
	</div>
<div id="content">

	<!-- Customer Banner -->
	<div id="customer-banner" >
		<fieldset class="fsCustomer" >
		<legend>Customer Information</legend>
			<div class="kitSpacers">
			<input id="customerDBA"  name="frm[customerDBA]" type="text" value="<?php echo $row['dba']?>" />
		</fieldset>
	</div>
</div>


<div id="rightCol">
	<!-- Order Info -->
	<div id="order-banner"></div>
</div>

	
	<div class="Push"></div>	
</div>		
<div id="footer">
	Copyright © Site name, 20XX
</div>


<!-- Chain Chart -->
	<div id="chainChart">
		<div id="chartList">Please select a pitch to select a chain</div>
	</div>


<!-- Chain Kit MSRP ect 	
	<div id="KitContent">
		<fieldset>
			<legend>Order Status</legend>
			
				<table width="100%">
					<tr>
						<th nowrap>Part Description</th>
						<th nowrap>MSRP</th>
						<th nowrap>Dealer Cost</th>
						<th nowrap>Import Cost</th>
					</tr>
					<tr>
						<td width="25%" nowrap>Front Sprocket</td>
						<td id="fsMSRP" style="text-align:right"><?php echo $utility->NumberFormat($row['msrp'])?></td>
						<td id="fsDealer" style="text-align:right"><?php echo $utility->NumberFormat($row['dealer_cost'])?></td>
						<td id="fsImport" style="text-align:right"><?php echo $utility->NumberFormat($row['import_cost'])?></td>
					</tr>
					<tr>
						<td width="25%">Rear Sprocket</td>
						<td id="rsMSRP" style="text-align:right"><?php echo $utility->NumberFormat($row['msrp'])?></td>
						<td id="rsDealer" style="text-align:right"><?php echo $utility->NumberFormat($row['dealer_cost'])?></td>
						<td id="rsImport" style="text-align:right"><?php echo $utility->NumberFormat($row['import_cost'])?></td>
					</tr>
					<tr>
						<td width="25%">Chain Length</td>
						<td id="clMSRP" style="text-align:right"><?php echo $utility->NumberFormat($row['msrp'])?></td>
						<td id="clDealer" style="text-align:right"><?php echo $utility->NumberFormat($row['dealer_cost'])?></td>
						<td id="clImport" style="text-align:right"><?php echo $utility->NumberFormat($row['import_cost'])?></td>
					</tr>
					<tr>
						<td width="25%">Total</td>
						<td id="totalMSRP" style="text-align:right"></td>
						<td id="totalDealer" style="text-align:right"></td>
						<td id="totalImport" style="text-align:right"></td>
					</tr>
				</table>
		</fieldset>
	</div>
-->	

	
<!-- Customer Update Dialog -->
	<div id="dialog-customer" title="Customer Information">
		<div id="customer"></div>
	</div>
	
<input type="hidden" id="cust_id" name="frm[cust_id]" value="id" />
<input type="hidden" id="cust_number" name="frm[cust_number]" value="cu" />


<div id="log"></div>
</body>
</html>
