<!- menu navigation  in/nav.inc.php-->
<ul>
	<li><a href="customer-list.php?search=D">Dealers</a></li>
	<li><a href="customer-list.php?search=R">Retail</a></li>
	<li><a href="customer-list.php">Customer list</a></li>
	<li><a href="part-list.php">Parts</a></li>
	<li><a href="chain-chart.php">Chain Charts</a></li>
	<li><a href="order-list.php">Orders</a></li>
	<li><a href="report-list.php">Reports</a></li>
	<li><a href="contact.php">Contact Us</a></li>
</ul>