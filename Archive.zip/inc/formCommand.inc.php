<!- Commands used on forms -->

	<input id="submit" name="submit" value="Submit" type="submit"/>
	<input id="recMode" name="recMode" value="<?php echo $recMode;?>" type="hidden"/>
	<input id="formAction" name="formAction" value="UPDATE" type="hidden"/>
