<!- menu navigation  includes/nav.php-->
<ul>
	<li><a href="index.php">Main</a></li>
	<li><a href="customer-list.php">Customers</a></li>
	<li><a href="part-list.php">Parts</a></li>
	<li><a href="kit.php">Chain Kits</a></li>
	<li><a href="chain-chart.php">Chain Charts</a></li>
	<li><a href="order-list.php">Orders</a></li>
	<li><a href="report-list.php">Reports</a></li>
	<li><a href="contact.php">Contact Us</a></li>
</ul>