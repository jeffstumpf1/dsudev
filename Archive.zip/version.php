<?php
echo sqlite_libversion();
echo "<br>";
echo phpversion();
?>