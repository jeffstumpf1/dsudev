// part.js

$(function() {
    	
    	$("#category").val(0);
    	$("#createSubmit").attr('disabled','disabled');
    	
    	
		$( "#search" ).on('mouseup', function() {
			 $(this).select(); 	
		});
		
		$("#category").change(function() {
		  	$sel = $('#category').val();
		 	if($sel != '*') {
		 		$('#createSubmit').removeAttr('disabled');
		 	} else
		 	  $("#createSubmit").attr('disabled','disabled');  
		});
		
		$('.actionStatus').click(function(e){
			e.preventDefault();
			$part = $(this).parent().attr('pn');
			$ct = $(this).parent().attr('ct');
			$title = 'Deleting Part ('+ $part + ')';
			$( "#dialog-confirm" ).dialog({
			  resizable: false,
			  height:200,
			  modal: true,
			  title: $title,
			  buttons: {
				"Delete": function() {
				  $( this ).dialog( "close" );
				  DeletePartSelected($part, $ct);
				},
				Cancel: function() {
				  $( this ).dialog( "close" );
				}
			  }
			});
			
		});
		
		function DeletePartSelected($part, $cat) {
		$.ajax({ 
			  type: 'GET',
			  url: 'service/delete-part.service.php',
			  data: { part_number: $part, cat: $cat },
			  beforeSend:function(){
				// load a temporary image in a div
			  },
			  success:function(data){
				//alert(data);
				location.reload();
			  },
			  error:function(){
				alert('Error: part not deleted');
			  }
			});
		}
});
