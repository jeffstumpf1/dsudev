<?php
header("Location: part-list.php");
?>